<script lang="javascript">(function() {var pname = document.title;var ga = document.createElement('script'); ga.type = 'text/javascript';ga.src = '//live.vnpgroup.net/js/web_client_box.php?hash=5378c8331d02b8d134d539fe2cc9a220&data=eyJzc29faWQiOjMyMTczMiwiaGFzaCI6IjhiZjE2YjQ5NTc5NDliM2YwNDA3NGM0OTU2OGQyMTYzIn0-&pname='+pname;var s = document.getElementsByTagName('script');s[0].parentNode.insertBefore(ga, s[0]);})();</script><noscript><a href="http://www.vatgia.com" title="vatgia.com" target="_blank">Tài trợ bởi vatgia.com</a></noscript><noscript><a href="http://vchat.vn" title="vchat.vn" target="_blank">Phát triển bởi vchat.vn</a></noscript><noscript><a href="http://123doc.org" title="123doc.org" target="_blank">Partner vchat.vn</a></noscript>	
  <footer>
	<div class="container">
		<div class="row">
			<div class="col-md-5 col-sm-12 col-xs-12">
				<div class="row">
					<div class="mgb-30 col-md-7 col-sm-6 col-xs-12">
						<div class="foo-info">
								
							<a href="/">	
							<img alt="noithatthoinay" src="//bizweb.dktcdn.net/100/022/286/themes/28873/assets/logo.png?1457574486889">
							</a>
							
							<br>
							
							<span>Chúng tôi mong muốn đưa thương hiệu NỘI THẤT Vi-Home trở thành biểu tượng số 1 tại Việt Nam cũng như toàn cầu về không gian sống và các sản phẩm nội ngoại thất, luôn chiếm được sự tin yêu của Quý khách hàng thông qua chất lượng cùng sự đa dạng của tất cả các chủng loại sản phẩm trong và ngoài nước</span>
							
							<form class="newsletter">
								<div class="input-group">
									<input type="text" class="form-control" placeholder="Email của bạn...">
									<span class="input-group-btn">
										<button class="btn btn-default" type="button"><i class="fa fa-envelope-o"></i></button>
									</span>
								</div>
							</form>
						</div>
					</div>       
					<div class="mgb-30 col-md-5 col-sm-6 col-xs-12">
						<div class="foo-title">
							<span>Thông tin</span>
						</div>
						<ul class="list-unstyled foo-content">
							
		                       <li><a href='/'>Trang chủ</a></li>
		                    
		                       <li><a href='/collections/all'>Sản phẩm</a></li>
		                    
		                       <li><a href='/tin-tuc'>Blog</a></li>
		                    
		                       <li><a href='/gioi-thieu'>Giới thiệu</a></li>
		                    
		                       <li><a href='/ban-do'>Bản đồ</a></li>
		                    
						</ul>                    
					</div>
				</div>
			</div>
			<div class="col-md-4 col-sm-12">
				<div class="row">
					<div class="mgb-30 col-md-6 col-sm-6">
						<div class="foo-title">
							<span>Hỗ trợ</span>
						</div>
						<ul class="list-unstyled foo-content">
							
		                       <li><a href='/'>Hướng dẫn mua hàng</a></li>
		                    
		                       <li><a href='/'>Hướng dẫn đổi trả</a></li>
		                    
		                       <li><a href='/'>Chính sách giao hàng</a></li>
		                    
		                       <li><a href='/'>Chính sách bảo mật</a></li>
		                    
						</ul>
					</div>
					<div class="mgb-30 col-md-6 col-sm-6">
						<div class="foo-title">
							<span>Liên kết</span>
						</div>
						<ul class="list-unstyled foo-content">
							
		                       <li><a href='/search'>Tìm kiếm</a></li>
		                    
		                       <li><a href='/gioi-thieu'>Giới thiệu</a></li>
		                    
						</ul>
					</div>
				</div>
			</div>
			<div class="mgb-30 col-md-3 col-sm-12">                   
				<div class="foo-title">
					<span>Liên hệ</span>
				</div>
				<div class="foo-info">
					<p class="foo-address">138 đường Cống Đặng, xã Hữu Bằng, huyện Thạch Thất, Hà Nội</p>
					<p><span class="foo-phone">0913.009.985</span>
					</p>
					<a href="mailto:dogodep99@gmail.com" class="foo-mail">dogodep99@gmail.com</a>

					<div class="fooFlowus">
						<ul class="list-unstyled">
							<li><a class="show_facebook" href="#" target="_blank" title="Facebook"><i class="fa fa-facebook"></i></a>
							</li>
							<li><a class="show_twitter" href="#" target="_blank" title="Twitter"><i class="fa fa-twitter"></i></a>
							</li>
							<li><a class="show_google" href="#" target="_blank" title="Google+"><i class="fa fa-google-plus"></i></a>
							</li>                                
							<li><a class="show_google" href="#" target="_blank" title="Pinterest"><i class="fa fa-pinterest-p"></i></a>
							</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
</footer>
<section class="copyright">
	<div class="container">            
		<div class="cpr col-sm-6 col-md-6 col-xs-12 pull-left"><span>©2015 - Vi-Home</span></div>
		<div class=" col-sm-6 col-md-6 col-xs-12">
			<div class="payment pull-right">
				<a href="#"><i class="fa fa-cc-visa"></i></a>
				<a href="#"><i class="fa fa-cc-mastercard"></i></a>
				<a href="#"><i class="fa fa-cc-paypal"></i></a>
				<a href="#"><i class="fa fa-cc-discover"></i></a>
			</div>
		</div>
	</div>
</section>


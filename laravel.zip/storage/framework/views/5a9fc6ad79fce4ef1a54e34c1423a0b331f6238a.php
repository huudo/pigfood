<!DOCTYPE html>
<html lang="en">

<head>
	<meta name="google-site-verification" content="9211v6IrzwDO4vs4jLFn2sUg_44PugO_hMMIfQeur00" />
    <meta charset="UTF-8">
    <title>
     Vi-Home        
    </title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
     
    <meta name="description" content=""> 
     
    
<link rel="shortcut icon" href="//bizweb.dktcdn.net/100/022/286/themes/28873/assets/favicon.png?1457574486889">
    
<link rel="stylesheet" type="text/css" href=<?php echo e(Asset('public/css/bootstrap.min.css')); ?>>
<link rel="stylesheet" type="text/css" href=<?php echo e(Asset('public/css/bootstrap-theme.min.css')); ?>>
<link href='//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css' rel='stylesheet' type='text/css' />

<link rel="stylesheet" type="text/css" href=<?php echo e(Asset('public/css/style.css')); ?>>
<script type="text/javascript" src=<?php echo e(Asset('public/js/jquery213.js')); ?>></script>
<script type="text/javascript" src=<?php echo e(Asset('public/js/jquery.hoverdir.js')); ?>></script>
<script type="text/javascript" src=<?php echo e(Asset('public/js/modernizr.custom.97074.js')); ?>></script>
<script type="text/javascript" src=<?php echo e(Asset('public/js/api.jquery.js')); ?>></script>
<script type="text/javascript" src=<?php echo e(Asset('public/js/bootstrap.min.js')); ?>></script>
</head>
<body>
	<script>
	  window.fbAsyncInit = function() {
	    FB.init({
	      appId      : '1727282974222089',
	      xfbml      : true,
	      version    : 'v2.5'
	    });
	  };

	  (function(d, s, id){
	     var js, fjs = d.getElementsByTagName(s)[0];
	     if (d.getElementById(id)) {return;}
	     js = d.createElement(s); js.id = id;
	     js.src = "//connect.facebook.net/en_US/sdk.js";
	     fjs.parentNode.insertBefore(js, fjs);
	   }(document, 'script', 'facebook-jssdk'));
	</script>
	<?php echo $__env->make('includes.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<div id="main">
		 <?php echo $__env->yieldContent('content'); ?>
	</div>
	<?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>
</html>